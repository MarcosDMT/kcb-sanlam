const countries = require('./countries.json');
export const EACountries = require('./ea_countries.json');

export default countries;