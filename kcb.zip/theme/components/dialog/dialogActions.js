import pxToRem from "../../functions/pxToRem";


export default {
  styleOverrides: {
    root: {
      padding: pxToRem(16),
    },
  },
};
